package model;

import java.io.Serializable;
import java.sql.Timestamp;

import exceptions.*;

public class Automobile implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String name;
	private float baseprice;
	private OptionSet opset[];

	// **************************************
	// ** Constructors **
	// **************************************

	// default constructor
	public Automobile() {
	}

	// constructor
	// building new Automotive object
	public Automobile(String name, float baseprice, int optionSetSize) {
		this.name = name;
		this.baseprice = baseprice;
		opset = new OptionSet[optionSetSize];
	}

	// **************************************
	// ** Getters **
	// **************************************
	/*
	 * 1. Get Name of Automotive 2. Get Automotive Base Price 3. Get OptionSet
	 * (by index value)
	 */

	public String getName() {
		return name;
	}

	public float getBasePrice() {
		return baseprice;
	}

	public OptionSet getOptionSet(int pos) {
		//System.out.println(opset[pos].getName());
		return opset[pos];
	}
	
	public int getOptionSetSize()
	{
		return opset.length;
	}
	

	// **************************************
	// ** Find **
	// **************************************
	// finding the position of OptionSet
	// if not found! return -1
	public int findOptionSet(String name) {
		//using for loop to go through the whole array
		int pos = 0;
		for (int i = 0; i < opset.length; i++) {
			if (name.equals(opset[i].getName()))
			{
				pos = i;
				break;
			}
			else
				pos = -1;
		}
		return pos;
	}

	// finding the position of Option in the OptionSet
	// if not found! return -1
	public int findOption(OptionSet optSet, String nameOfOption) {
		// find optset passed into this function using findOptionSet class.
		// Then find option.
		return optSet._findOption(nameOfOption);
	}

	// **************************************
	// ** Setters **
	// **************************************
	/**
	 * i. SetName 
	 * ii. Set Base Price 
	 * iii. Set values of OptionSet 
	 * iv. Set values of Option (in context of OptionSet)
	 */
	public void setName(String _name) {
		_name = name;
	}

	public void setBasePrice(float _baseprice) {
		_baseprice = baseprice;
	}
	
	public void setOpset(int size)
	{
		opset = new OptionSet[size];
	}

	public void setValueofOptionSet(int i, String name, int size) {
		opset[i] = new OptionSet(name, size);
	}

	public void setValueofOption(OptionSet opst, int i, String name, int price) {
		// using inner class method to set value
		opst.setOption(i, name, price);
	}

	// **************************************
	// ** Delete **
	// **************************************
	public boolean deleteOption(OptionSet OptSet, int pos) {
		//using inner class method to delete value
		if (OptSet._deleteOption(pos))
			return true;
		else
			return false;
	}

	public boolean deleteOptionSet(int pos) {
		if (pos >= 0 && pos < opset.length) {
			opset[pos] = new OptionSet();
			return true;
		}
		return false;
	}

	// **************************************
	// ** Update **
	// **************************************
	public void updateOption(OptionSet OptSet, String name, float newPrice)
	{
		// using inner class to update value
		//int i = findOption(OptSet, newName);
        java.util.Date date= new java.util.Date();
		do{
			try{
				int i = findOption(OptSet, name);
				if(i == -1)
					throw new ExceptionManager(102, "Option Not Found!");
				else{
						OptSet._updateOption(i, name, newPrice);
						break;
					}
			}catch(ExceptionManager e) {
		        System.out.println(new Timestamp(date.getTime()));// TIMESTAMP
				System.out.println("Exception Captured!");
				name = e.fix(102);
			}
		}while(true);
	}
	
	public void updateOptionSet(String name, String newName)
	{
        java.util.Date date= new java.util.Date();
		do{
			try{
				int i = findOptionSet(name);
				if(i == -1)
					throw new ExceptionManager(101, "Option Set Not Found!");
				else{
					//System.out.println(newName);
					if(i >= 0 && i < opset.length)
						opset[i].setName(newName);
					break;
					//switcher = true;
					}
			}catch(ExceptionManager e) {
		        System.out.println(new Timestamp(date.getTime())); // TIMESTAMP
				System.out.println("Exception Captured!");
				name = e.fix(101);
			}
		}while(true);

	}
	
	// **************************************
	// ** Print **
	// **************************************
	public void print()
	{
		System.out.println("Model: " + getName());
		System.out.println("Base Price: " + getBasePrice());
		for(int i = 0; i < opset.length; i ++)
		{
			System.out.println("- - - - - - - - - - - - - - - - - - - - - - - - -");
			System.out.println(opset[i].getName() + ": ");
			for(int c = 0; c < opset[i].getSize(); c++){
				opset[i]._print(c);
			}
		}
	}
}
