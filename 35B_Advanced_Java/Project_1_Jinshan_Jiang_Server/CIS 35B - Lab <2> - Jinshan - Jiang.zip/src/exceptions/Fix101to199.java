package exceptions;
//import java.util.Scanner;

public class Fix101to199 {
	// **************************************
	// ** 101  -->  Option Set Name Not Found**
	// **************************************
	/**
	 * this is an incomplete fixing method, 
	 * fixing input is still hard coded.
	 * */
	public String fix101()
	{
		String newname;
		System.out.println("Trying to fix exception #101...");
		//System.out.println("Please re-enter the Option Set name:");
		//Scanner in= new Scanner(System.in);
		newname = "Transmission";
		//newname = in.next();
		//in.close();
		return newname;
	}
	
	// **************************************
	// ** 102 -->  Option Name Not Found**
	// **************************************
	/**
	 * this is an incomplete fixing method, 
	 * fixing input is still hard coded.
	 * */
	public String fix102()
	{
		//Scanner in= new Scanner(System.in);
		String newname;
		System.out.println("Trying to fix exception #102...");
		//System.out.println("Please re-enter the Option name:");
		newname = "Selected";
		//in.close();
		return newname;
	}
}
