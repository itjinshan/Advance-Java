package exceptions;

public class ExceptionManager extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	// properties
	// error number to log error number
	// string to store error message
	private int errorno;
	private String errormsg;
	
	// **************************************
	// ** Constructors **
	// **************************************
	public ExceptionManager() {
		super();
		printmyproblem();
	}
	
	public ExceptionManager(String errormsg) {
		super();
		this.errormsg = errormsg;
		printmyproblem();
	}
	
	public ExceptionManager(int errorno) {
		super();
		this.errorno = errorno;
		printmyproblem();
	}
	
	public ExceptionManager(int errorno, String errormsg) {
		super();
		this.errorno = errorno;
		this.errormsg = errormsg;
		printmyproblem();
	}
	
	// **************************************
	// ** Setters and getters **
	// **************************************
	public int getErrorno() {
		return errorno;
	}
	
	public void setErrorno(int errorno) {
		this.errorno = errorno;
	}
	
	public String getErrormsg() {
		return errormsg;
	}
	
	public void setErrormsg(String errormsg) {
		this.errormsg = errormsg;
	}
	
	// **************************************
	// ** Print Method **
	// **************************************
	public void printmyproblem() {
		System.out.println("FixProblems [errorno = " + errorno + ", errormsg: " + errormsg); 
	}

	// **************************************
	// ** Fix Method**
	// **************************************
	public String fix(int errno) {
		//declaring a Fix101to199 object to access to the class
		Fix101to199 f1 = new Fix101to199(); 
		//declaring a Fix201to299 object to access to the class
		Fix201to299 f2 = new Fix201to299();
		
		//using switch statement to chose right method to fix different problem
		switch(errno){
			case 101: 
				return f1.fix101();
				
			case 102:
				return f1.fix102();
				
			case 201:
				return f2.fix201();
				
			case 202:
				return f2.fix202();
				
			default:
				return "This went into default!";
		}
	}
}
