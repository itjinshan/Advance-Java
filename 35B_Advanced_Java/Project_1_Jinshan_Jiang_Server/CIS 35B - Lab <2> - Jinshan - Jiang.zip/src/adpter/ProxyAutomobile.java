package adpter;
import model.*;
import util.*;
public abstract class ProxyAutomobile {
	//Variable a1 can be used for handling all operations on Automobile 
	//as needed by the interfaces.
	private Automobile a1;
	
	public void buildAuto(String filename)
	{
		ReadSource rs = new ReadSource();
		a1 = rs.read(filename);
	}
	
	public void printAuto(String modelName)
	{
		if(modelName.equals(a1.getName()))
			a1.print();
		else
			System.out.println("Automobile Not Found!!");
	}
	
	public void updateOptionSetName(String modelname, String optionSetname,
											String newName)
	{
		a1.updateOptionSet(optionSetname, newName);
		System.out.println("*******************");
		System.out.println("~ Option Set updated!");
		System.out.println("*******************");
	}
	
	public void updateOptionPrice(String modelname, String optionSetname, 
			String option, float newprice)
	{
		a1.updateOption(a1.getOptionSet(a1.findOptionSet(optionSetname)), option, newprice);
		System.out.println("*******************");
		System.out.println("~ Option Updated!");
		System.out.println("*******************");
	}
}
