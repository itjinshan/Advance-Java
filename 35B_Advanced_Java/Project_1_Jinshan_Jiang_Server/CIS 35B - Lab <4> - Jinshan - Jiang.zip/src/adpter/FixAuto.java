package adpter;

public interface FixAuto {
	public void fix101(int errNo);
}
