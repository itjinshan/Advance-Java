package adpter;

public class BuildAuto extends ProxyAutomobile implements CreateAuto, UpdateAuto { 
		
}
