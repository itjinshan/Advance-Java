package socketClient;

public interface SocketClientConstants
{
    int EchoP = 7;
    int DaytimeP = 13;
    int SmtpP = 25;
    boolean SWITCH = true;
}