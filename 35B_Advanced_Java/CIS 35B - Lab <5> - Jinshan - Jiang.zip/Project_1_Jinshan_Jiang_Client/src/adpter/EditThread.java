package adpter;

public interface EditThread {
	// one method
	public void updateT(int operation, String [] newData);
}
