package exceptions;

public class Fix201to299 {
	
	// **************************************
	// ** 201 -->  File Not Found**
	// **************************************
	/**
	 * this is an incomplete fixing method, 
	 * fixing input is still hard coded.
	 * */
	public String fix201(){
		String fileName;
		//System.out.println("Please re-enter the Option Set name:");
		//Scanner in= new Scanner(System.in);
		fileName = "Car Info.txt";
		//newname = in.next();
		//in.close();
		return fileName;
	}
	
	// **************************************
	// ** 202 --> Missing Base Price**
	// **************************************
	/**
	 * this is an incomplete fixing method, 
	 * fixing input is still hard coded.
	 * Also, for base price, return as a string
	 * then covert to a float in update method
	 * because this is a easier way to handle all the data type
	 * */
	public String fix202(){
		String baseprice;
		//System.out.println("Please re-enter the Option Set name:");
		//Scanner in= new Scanner(System.in);
		baseprice = "18445";
		//newname = in.next();
		//in.close();
		return baseprice;
	}
	
	// **************************************
	// ** 203 -->  File Not Found**
	// **************************************
	/**
	 * this is an incomplete fixing method, 
	 * fixing input is still hard coded.
	 * */
	public String fix203(){
		String fileName;
		//System.out.println("Please re-enter the Option Set name:");
		//Scanner in= new Scanner(System.in);
		fileName = "Property File.txt";
		//newname = in.next();
		//in.close();
		return fileName;
	}
}
