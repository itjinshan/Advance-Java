package socketServer;

public interface SocketServerConstants
{
    int EchoP= 7;
    int DaytimeP = 13;
    int SmtpP= 25;
    boolean SWITCH = true;
}