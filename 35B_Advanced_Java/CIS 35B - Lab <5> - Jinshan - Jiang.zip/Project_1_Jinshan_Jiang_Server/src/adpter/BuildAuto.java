package adpter;

import server.AutoServer;

public class BuildAuto extends ProxyAutomobile implements CreateAuto, UpdateAuto, EditThread, AutoServer { 
		
}
